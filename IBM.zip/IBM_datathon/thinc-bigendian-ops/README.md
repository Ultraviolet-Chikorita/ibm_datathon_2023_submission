
# thinc-bigendian-ops

Make [thinc](https://thinc.ai) models portable to Big Endian platforms. 

Currently, this support enables the use of thinc models trained on little endian platforms; this includes spaCy 
pipelines such as en_core_web_sm (and other nnn_sm language packs). 
